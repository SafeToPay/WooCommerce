<?php
/**
 * Admin help message.
 *
 * @package WooCommerce_Safe2Pay/Admin/Settings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
