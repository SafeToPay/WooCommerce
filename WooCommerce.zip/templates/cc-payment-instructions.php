<?php if (!defined('ABSPATH')) exit; ?>

<div class="woocommerce-message">

    <span>
        <?php esc_html_e($description, 'woo-safe2pay'); ?>
    </span>

</div>